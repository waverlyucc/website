<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__PUE__Utility' );


	class TribePluginUpdateUtility extends Tribe__PUE__Utility {

	}
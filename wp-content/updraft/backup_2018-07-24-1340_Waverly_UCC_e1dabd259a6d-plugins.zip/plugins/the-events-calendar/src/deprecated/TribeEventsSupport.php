<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Support' );


	class TribeEventsSupport extends Tribe__Support {

	}
